package com.hrm.testcases;

import org.testng.annotations.Test;
import org.testng.asserts.SoftAssert;

import com.hrm.pages.HomePage;
import com.hrm.utilities.CommanMethods;
import com.hrm.utilities.ConfigReader;
import com.hrm.pages.ForGotPassword;
public class VerifyForgotPassword {
	/*@Test
	public void passWordRest() {

		HomePage homepage = new HomePage();
		//CommanMethods.sendText(homepage.userid, ConfigReader.getProperty("username"));
		//CommanMethods.sendText(forGotPassword.password, ConfigReader.getProperty("password"));
		CommanMethods.click(homepage.forgotpasswordlink);
		//String actualTitle = driver.getTitle();
		//System.out.println("Title of page" + actualTitle);
		CommanMethods.sendText(homepage.userid, ConfigReader.getProperty("username"));
		CommanMethods.click(ForGotPassword.);
		CommanMethods.click(ForGotPassword.resetpassword);
		SoftAssert sa = new SoftAssert();
		sa.assertEquals("OrangeHRM", actualTitle, "titles are not matching");
		sa.assertAll();

	}
*/
}
