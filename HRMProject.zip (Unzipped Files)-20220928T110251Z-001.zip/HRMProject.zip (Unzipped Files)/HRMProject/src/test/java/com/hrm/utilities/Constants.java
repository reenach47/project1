package com.hrm.utilities;

public class Constants {

	
	public static final String CHROME_DRIVER_PATH="C:\\Ashok\\chromedriver.exe";
	
    public static final String GECKO_DRIVER_PATH="";
    public static final int IMPLICIT_WAIT_TIME=40;
    public static final String CONFIGS_FILE_PATH="C:\\Users\\Admin\\eclipse-workspace\\HRMProject\\Configuration\\configs.properties";
}
